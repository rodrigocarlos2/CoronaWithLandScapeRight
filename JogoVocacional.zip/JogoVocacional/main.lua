-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local webView = native.newWebView(display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight)
webView:request("https://test1-c3f44.firebaseapp.com/")